$(document).ready(function(){
	
	$('.show-modal').click(function(){
		$('.modal').modal('hide');
		$($(this).data('target')).modal('show');
	});		
	
 var open = $('#sidebar-wrapper'),
        close = $('#sidebar-wrapper');
        /* overlay = $('.overlay'); */

    open.on('mouseover',function() {
        /* overlay.show(); */
        $('#nav_overlay').addClass('toggled');
    });
	open.on('mouseleave',function(e){
		/* overlay.hide(); */
		$('#nav_overlay').removeClass('toggled');		
	});		 
});